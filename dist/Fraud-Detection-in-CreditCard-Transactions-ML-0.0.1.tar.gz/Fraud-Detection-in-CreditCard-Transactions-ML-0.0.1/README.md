A project to demonstrate the creation of ML pipeline

Step 1: Create a virtual environment
```
conda create -p myvenv python==3.10
```
Step2: Create setup.py

Step3: Create requirements.txt